import os
import torch
import pandas as pd
import cv2
import numpy as np
import random
import torch
from torch.utils.data import Dataset, DataLoader
import math
import os 
from glob import glob

#data_set = Spoofing_train_oulu(os.path.join(data_dir, "train_list_video.txt"), os.path.join(data_dir, "Train_files"), transform=transform, img_size=img_size, map_size=map_size, UUID=UUID)

class Spoofing_train(Dataset):
    
    def __init__(self, info_list, root_dir, transform=None, scale_up=1.5, scale_down=1.0, img_size=256, map_size=32, UUID=-1):
        self.landmarks_frame = pd.read_csv(info_list, delimiter=",", header=None)
        self.root_dir = root_dir
        self.transform = transform
        self.scale_up = scale_up
        self.scale_down = scale_down
        self.img_size = img_size
        self.map_size = map_size
        self.UUID = UUID

    def __len__(self):
        return len(self.landmarks_frame)
    
    def __getitem__(self, idx):
        image_name = str(self.landmarks_frame.iloc[idx, 0])
        image_dir = os.path.join(self.root_dir, image_name)
        spoofing_label = self.landmarks_frame.iloc[idx, 1]
        if spoofing_label == 1:
            spoofing_label = 1            # real
        else:
            spoofing_label = 0             # fake
        image_x, map_x = self.get_single_image_x(image_dir, spoofing_label)
        sample = {"image_x": image_x, "label": spoofing_label, "map_x": map_x, "UUID": self.UUID}
        if self.transform:
            sample = self.transform(sample)
        return sample

    def get_single_image_x(self, image_dir, spoofing_label):
        try:
            image_x_temp = cv2.imread(image_dir)
            image_x = cv2.resize(image_x_temp, (self.img_size, self.img_size))
        except:
            print(image_dir)

        if spoofing_label == 1:
            map_x = np.ones((self.map_size, self.map_size))
        else:
            map_x = np.zeros((self.map_size, self.map_size))

        return image_x, map_x